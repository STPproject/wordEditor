import './App.css';
import TextEditor from './component/TextEditor';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      </header>
      <div className='editor'>
        <TextEditor />
      </div>
    </div>
  );
}

export default App;
